# TradeLab Android APK

1. ZIP extract karo.
2. Extracted project ki files GitHub repository ke root mein upload karo.
3. `.github/workflows/android-apk.yml` file banao aur workflow text paste karo (separate file `GITHUB-ACTIONS-WORKFLOW.yml.txt` mein diya hai).
4. GitHub ke Actions tab mein Android APK Build chalao.
5. Run ke Artifacts se `TradeLab-debug-apk` download karo; ZIP extract karke APK install karo.

Note: Ye educational paper-trading demo hai. Prices simulated hain; verified NSE live feed, Groww login, aur real-money orders included nahi hain.
